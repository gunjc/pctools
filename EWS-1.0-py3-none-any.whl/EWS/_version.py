
__version__ = '1.0'  # 1.0 - Sep 05, 2019
