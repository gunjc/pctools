"""
An Outlook interface to send emails
"""

import os
import sys
import queue
import getpass
import threading
from collections import namedtuple

here = os.path.dirname(os.path.abspath(__file__))
assemblies_path = os.path.join(here, r'assemblies.net')
sys.path.append(assemblies_path)

import clr
clr.AddReference('Microsoft.Exchange.WebServices')
from Microsoft.Exchange.WebServices import Data
clr.AddReference('System')
import System


__all__ = ['EWSError', 'UnresolvedUserError', 'AmbiguousResolutionsError',
           'EWSClient', 'RMCURVAS_ADDRESS']

_EWS_URL = "https://owa.santander.com.br/EWS/exchange.asmx"
RMCURVAS_ADDRESS = "riscosmercado@santander.com.br"


# ---------- Module's Exceptions ----------------

class EWSError(Exception):
    """Base class for exceptions in this module"""
    pass


class UnresolvedUserError(EWSError):
    """Exception raised when EWS cannot locate a user"""
    pass


class AmbiguousResolutionsError(EWSError):
    """Exception raised when EWS finds multiple resolutions for a user"""
    pass


# ---------- Main Class -------------------------

class EWSClient:
    """Base class for sending emails and interacting with Exchange"""

    User = namedtuple('User', 'login name email_address')

    def __init__(self, url=_EWS_URL):
        self.service = Data.ExchangeService(Data.ExchangeVersion.Exchange2007_SP1)
        self.service.Url = System.Uri(url)
        self.service.UseDefaultCredentials = True

        self._mail_queue = queue.Queue()

        self._m_thread = threading.Thread(target=self.__mailer_thread)
        self._m_thread.daemon = True
        self._m_thread.start()

    def get_user_info(self, user_login=None):
        r"""
        Tries to find out an user's info given its login.

        Parameters
        ----------
        user_login: str, optional
            The user login (usually in the format 't\d\d\d\d\d\d', where '\d'
            is a digit from 0 to 9). If None, will use the login of the
            current user logged in the PC.

        Returns
        -------
        collections.namedtuple
            A namedtuple with fields 'login', 'name' and 'email_address'
            of the user.

        Raises
        ------
        UnresolvedUserError
            If the login given is invalid or doesn't exist

        AmbiguousResolutionsError
            If the login was found but there is more than one resolution
            for the given user.

        Examples
        --------

        >>> ews = EWSClient()
        >>> usr = ews.get_user_info('t693318')
        >>> usr
        User(login='t693318', name='Sergio Agapito Lires Rial',
        email_address='srial@santander.com.br')

        Accessing user's attributes:

        >>> usr.name
        'Sergio Agapito Lires Rial'
        >>> usr.email_address
        'srial@santander.com.br'
        """
        if user_login is None:
            user_login = getpass.getuser()
        res = self.service.ResolveName(user_login)
        res_count = res.Count
        if res_count > 1:
            raise AmbiguousResolutionsError(f'{res_count} (stop at 100) '
                                            f'ambiguous resolutions for '
                                            f'{user_login}')
        elif res_count == 0:
            raise UnresolvedUserError(f'Cannot resolve {user_login}')

        return self.User(user_login, res[0].Mailbox.Name, res[0].Mailbox.Address)

    def __mailer_thread(self):
        while True:
            email_function, callback = self._mail_queue.get()
            if email_function is None:
                # None signals thread is done, finish it
                self._mail_queue.task_done()
                break
            try:
                email_function()
            except Exception as e:
                if callback is not None:
                    callback(e)
            finally:
                self._mail_queue.task_done()

    def __make_email_message(self, subject, body, recipients, cc, bcc, importance,
                             attachments, body_type, send_as_rmcurvas):
        email = Data.EmailMessage(self.service)
        cc = cc or []
        bcc = bcc or []
        attachments = attachments or []
        if send_as_rmcurvas:
            email.From = Data.EmailAddress(RMCURVAS_ADDRESS)
        email.Subject = subject
        email.Body = Data.MessageBody(body_type, body)
        email.Importance = importance
        for r in recipients:
            email.ToRecipients.Add(r)
        for r in cc:
            email.CcRecipients.Add(r)
        for r in bcc:
            email.BccRecipients.Add(r)
        for a in attachments:
            email.Attachments.AddFileAttachment(a)
        return email

    def send_mail(self, subject, body, recipients, *, cc=None, bcc=None,
                  blocking=False, attachments=None, importance=1, callback=None,
                  body_type='html', save_copy=True, send_as_rmcurvas=False):
        r"""
        Sends an email with the given characteristics

        Parameters
        ----------
        subject: str
            Email's subject
        body: str
            Email's body. Can be an HTML formatted string or plain text. See
            ``body_type``
        recipients: list of str
            A list of 1 or more email addresses
        cc, bcc: list of str, optional
            A list of 1 or more email addresses
        blocking: bool, default False
            Whether to send the email asynchronously (default) or blocking.
        attachments: list of str
            A list of filepaths to be attached to the message
        importance: {0, 1, 2}, default 1
            Email's importance. 0 is low importance, 1 is normal importance
            (default) and 2 is high importance (a red exclamation mark will
            appear besides the email)
        callback: Callable, optional
            A function to handle an Exception if the internal EWS SendMail
            method raised one. Only used if ``blocking`` is False, else this
            has no effect. Example functions: `print` or `logging.error`
        body_type: {'html', 'text'}, default 'html'
            How to render the ``body``. if 'html' (default) will render as
            HTML, if 'text' will render as plain text.
        save_copy: bool, default True
            If True, a copy of the email will be saved to the sender's 'Sent
            Items' folder
        send_as_rmcurvas: bool, default False
            Send the email as from 'Riscos de Mercado - Curvas'

        Examples
        --------
        Sending a simple email

        >>> ews = EWSClient()
        >>> ews.send_mail('Report', 'Some data', ['joe@example.com'])

        Adding attachments:

        >>> ews.send_mail('Report', 'See attached files', ['joe@example.com'],
        ...     bcc=['secret@example.com', 'fbi@example.com'], attachments=
        ...     [r'C:\Docs\report.pdf', r'C:\Docs\report.docx']
        ... )

        Sending a pandas dataframe as an HTML formatted table in the body

        >>> import pandas as pd
        >>> df = pd.read_csv('example.csv')
        >>> ews.send_mail('The data', df.to_html(), ['receiver@example.com'])
        """

        body_type = {
            'HTML': Data.BodyType.HTML, 'TEXT': Data.BodyType.Text,
        }[body_type.upper()]

        email = self.__make_email_message(
            subject, body, recipients, cc, bcc, importance, attachments,
            body_type, send_as_rmcurvas
        )

        email_function = email.SendAndSaveCopy if save_copy else email.Send

        if blocking:
            email_function()
        else:
            if not self._m_thread.is_alive():
                raise EWSError("Can't send an asynchronous "
                               "mail on a shutdown instance")
            self._mail_queue.put((email_function, callback))

    def shutdown(self):
        """
        Closes asynchronous mailer thread, so sending asynchronous emails (with
        the `send_mail` method with ``blocking`` set to False) will not be
        possible anymore. Called automatically in a context manager.

        Examples
        --------
        `shutdown` is called automatically at the end of the with block:

        >>> with EWSClient() as ews:
        ...     ews.send_mail('Subj', 'Body', ['rec@example.com'])
        """
        # send a quit thread signal to __mailer_thread
        if self._m_thread.is_alive():
            self._mail_queue.put((None, None))
            self._mail_queue.join()
            self._m_thread.join()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
