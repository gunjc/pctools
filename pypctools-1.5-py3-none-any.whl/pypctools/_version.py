# Em caso de mudanças (nova dist), atualizar versão somente aqui
__version__ = '1.5'
